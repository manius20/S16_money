#version 330
#define cA 1
#define cB 1
#define dm 1
#define dn 1
#define dp 1
#if !defined(IS_GUI)&& !defined(IS_SEE_THROUGH)
#moj_import <minecraft:sample_lightmap.glsl>
#endif
#moj_import <minecraft:hexo_s6.glsl>
void main(){hexoMain();}

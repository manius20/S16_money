#version 330
#define cA 1
#define cB 1
#define dm 1
#define dn 1
#define dp 1
#if defined(PER_FACE_LIGHTING)|| !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:hexo_s0.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV1;in ivec2 UV2;in vec3 Normal;
#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif
#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif
out float sphericalVertexDistance;out float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;out vec4 vertexPerFaceColorFront;
#endif
out vec4 vertexColor;out float bC;
#ifndef EMISSIVE
out vec4 lightMapColor;
#endif
#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif
out vec2 texCoord0;
#moj_import <minecraft:hexo_ext_pin_vsh.glsl>
flat out vec4 bD;out vec3 bE;
#if defined(ALPHA_CUTOUT)&& !defined(EMISSIVE)&& !defined(NO_OVERLAY)&& !defined(APPLY_TEXTURE_MATRIX)
#define bB 1
#endif
#ifdef bB
uniform sampler2D Sampler0;out float bH;out vec2 bI;
#define cC 1024.0
#define cD (0.5*cC)
#define cE 262144.0
#define cF 4096.0
#define cG 4096.0
#define bJ 64
#define cH 1.5
#define cI (16.0/9.0)
#define cJ -0.888
#define cK 0.036
#define cL 48.0
#define cM 1
#define cN 10
#define cO 17
#define cP 18
#define cQ 22
#define cR 28
#define cS 37
#define cT normalize(vec3(0.35,0.9,0.6))
#define cU normalize(vec3(-0.55,0.75,0.35))
void cV(){sphericalVertexDistance=0.0;cylindricalVertexDistance=0.0;lightMapColor=vec4(1.0);
#ifdef PER_FACE_LIGHTING
vec2 cW=minecraft_compute_light(cT,cU,Normal);vertexPerFaceColorBack=minecraft_mix_light_separate(-cW,Color);vertexPerFaceColorFront=minecraft_mix_light_separate(cW,Color);vertexColor=vertexPerFaceColorFront;
#elif !defined(NO_CARDINAL_LIGHTING)
vertexColor=minecraft_mix_light(cT,cU,Normal,Color);
#endif
}bool cX(){if(abs(ProjMat[2][3])<=10e-6||FogRenderDistanceEnd<=FogRenderDistanceStart){return false;}int cY= -int((Position.y-cD)/cC);if(cY<cM){return false;}ivec2 cZ=textureSize(Sampler0,0);bool da=cZ.x==bJ&&cZ.y==bJ;if(cY<=cN){if(!da){return false;}vec3 db=Position;db.y+=cC*float(cY);gl_Position=ProjMat*ModelViewMat*vec4(db,1.0);sphericalVertexDistance=fog_spherical_distance(db);cylindricalVertexDistance=fog_cylindrical_distance(db);bH=float(cY);return true;}vec3 dc=Position;cY=int(floor(-Position.y/cE+0.5));bool dd=cY>=cO&&cY<=cS;if(dd){dc.y+=cE*float(cY);dc/=cF;}else{cY=int(floor(-Position.y/cC+0.5));dc.y+=cC*float(cY);}int de=int(floor((dc.x+0.5*cG)/cG));dc.x-=cG*float(de);bool df=dd&&cY>=cP&&cY<=cQ;bool dg=df||(dd&&cY==cO)||(cY>=cR&&cY<=cS);if(!dg||(df&& !da)){return false;}if(df){bH=float(cY-cP+1);}bD=de>0?hexoPdClipWindow(de):vec4(0.0);float dh= -dc.z;if(dh<0.05){gl_Position=vec4(0.0);bD=vec4(0.0);return true;}float di=aQ(cJ+cK*clamp(dh/cL,0.0,1.0));gl_Position=vec4(cH*dc.x/cI,cH*dc.y,di*dh,dh);bE=vec3(gl_Position.xy,gl_Position.w);cV();return true;}
#endif
#moj_import <minecraft:hexo_s9.glsl>
#moj_import <minecraft:hexo_ext_item_vsh.glsl>
#define aA -80000.0
#define aB -320000.0
bool hexoTryMain(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);
#ifdef PER_FACE_LIGHTING
vec2 dj=minecraft_compute_light(Light0_Direction,Light1_Direction,Normal);vertexPerFaceColorBack=minecraft_mix_light_separate(-dj,Color);vertexPerFaceColorFront=minecraft_mix_light_separate(dj,Color);vertexColor=vertexPerFaceColorFront;
#elif defined(NO_CARDINAL_LIGHTING)
vertexColor=Color;
#else
vertexColor=minecraft_mix_light(Light0_Direction,Light1_Direction,Normal,Color);
#endif
#ifndef EMISSIVE
lightMapColor=sample_lightmap(Sampler2,UV2);
#endif
#ifndef NO_OVERLAY
overlayColor=texelFetch(Sampler1,UV1,0);
#endif
texCoord0=UV0;
#ifdef APPLY_TEXTURE_MATRIX
texCoord0=(TextureMat*vec4(UV0,0.0,1.0)).xy;
#endif
bool dk=false;bD=vec4(0.0);bE=vec3(0.0,0.0,1.0);
#ifdef bB
int dl=gl_VertexID%4;bH=0.0;bI=vec2(dl==1||dl==2?1.0:0.0,dl>=2?1.0:0.0);dk=cX();
#endif
if(Position.y<=aA&&Position.y>=aB&&aP()){sphericalVertexDistance=0.0;cylindricalVertexDistance=0.0;
#ifndef EMISSIVE
lightMapColor=vec4(1.0);
#endif
gl_Position.z=aQ(aR(Position));int aS=aT(UV2);bD=aS>0?hexoPdClipWindow(aS):vec4(0.0);bE=vec3(gl_Position.xy,1.0);dk=true;}if(hexoExtItemVertex()){dk=true;}bC=dk?1.0:0.0;return dk;}void main(){hexoTryMain();}

#version 330
#define dp 1
#moj_import <minecraft:hexo_s5.glsl>
void main(){hexoMain();}

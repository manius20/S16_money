#version 330
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
layout(std140)uniform Globals{vec2 ScreenSize;float GlintAlpha;float GameTime;int MenuBlurRadius;};int c(){if(GameTime>= -0.0001){return 0;}return int(floor(-GameTime*24000.0/750.0+0.5));}bool f(vec3 h){if((c()&8)==0){return false;}vec2 j=vec2(2.0/ProjMat[0][0],-2.0/ProjMat[1][1]);vec2 i=h.xy-floor((j-vec2(176.0,166.0))*0.5);return i.x>=0.0&&i.x<=176.0&&i.y>=0.0&&i.y<=166.0;}in vec3 Position;in vec4 Color;out vec4 vertexColor;void main(){if(f(Position)){gl_Position=vec4(2.0,2.0,2.0,1.0);return;}gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);vertexColor=Color;}

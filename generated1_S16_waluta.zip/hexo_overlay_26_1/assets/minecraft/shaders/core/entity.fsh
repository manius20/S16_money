#version 330
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;
#if defined(ALPHA_CUTOUT)&& !defined(EMISSIVE)&& !defined(NO_OVERLAY)&& !defined(APPLY_TEXTURE_MATRIX)
#define bB 1
#endif
#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif
#ifndef EMISSIVE
in vec4 lightMapColor;
#endif
#ifndef NO_OVERLAY
in vec4 overlayColor;
#endif
in vec2 texCoord0;in float bC;out vec4 fragColor;flat in vec4 bD;in vec3 bE;void bF(){if(bD.z>bD.x){vec2 bG=bE.xy/bE.z;if(bG.x<bD.x||bG.x>bD.z||bG.y<bD.y||bG.y>bD.w){discard;}}}
#ifdef bB
in float bH;in vec2 bI;
#define bJ 64.0
#define bK 8.0
#define bL vec2(54.0/bJ,20.0/bJ)
#define bM vec2(55.0/bJ,20.0/bJ)
#define bN 12.0
#define bO 8.0
#define bP 0.25
const vec4[]bQ=vec4[](vec4(4.0,0.0,8.0,4.0),vec4(8.0,0.0,12.0,4.0),vec4(0.0,4.0,4.0,16.0),vec4(4.0,4.0,8.0,16.0),vec4(8.0,4.0,12.0,16.0),vec4(12.0,4.0,16.0,16.0),vec4(4.0,0.0,7.0,4.0),vec4(7.0,0.0,10.0,4.0),vec4(0.0,4.0,4.0,16.0),vec4(4.0,4.0,7.0,16.0),vec4(7.0,4.0,11.0,16.0),vec4(11.0,4.0,14.0,16.0),vec4(4.0,0.0,12.0,4.0),vec4(12.0,0.0,20.0,4.0),vec4(0.0,4.0,4.0,16.0),vec4(4.0,4.0,12.0,16.0),vec4(12.0,4.0,16.0,16.0),vec4(16.0,4.0,24.0,16.0));const vec2[]bR=vec2[](vec2(40.0,16.0),vec2(40.0,32.0),vec2(32.0,48.0),vec2(48.0,48.0),vec2(16.0,16.0),vec2(16.0,32.0),vec2(0.0,16.0),vec2(0.0,32.0),vec2(16.0,48.0),vec2(0.0,48.0));const int[]bS=int[](0,0,1,1,2,3,4,5);const mat4 bT=mat4(0.0/16.0,8.0/16.0,2.0/16.0,10.0/16.0,12.0/16.0,4.0/16.0,14.0/16.0,6.0/16.0,3.0/16.0,11.0/16.0,1.0/16.0,9.0/16.0,15.0/16.0,7.0/16.0,13.0/16.0,5.0/16.0);bool bU(){vec4 bV=texture(Sampler0,bL);vec4 bW=texture(Sampler0,bM);return bV.a==0.0||(((bV.r+bV.g+bV.b)==0.0)&&((bW.r+bW.g+bW.b)==0.0)&&bV.a==1.0&&bW.a==1.0);}vec2 bX(out vec2 bY){vec2 bZ=texCoord0*bJ;vec2 ca=dFdx(bZ);vec2 cb=dFdy(bZ);vec2 cc=dFdx(bI);vec2 cd=dFdy(bI);bY=texCoord0;int ce=int(bH+0.5)-1;if(ce<0){return texCoord0;}vec2 cf=bZ;float cg=cc.x*cd.y-cd.x*cc.y;if(abs(cg)>1e-12){vec2 ch=(ca*cd.y-cb*cc.y)/cg;vec2 ci=(cb*cc.x-ca*cd.x)/cg;cf+=ch*(0.5-bI.x)+ci*(0.5-bI.y);}ivec2 cj=clamp(ivec2(floor(cf/bK)),ivec2(0),ivec2(7,1));vec2 ck=clamp(bZ/bK-vec2(cj),0.0,1.0);int cl=ce%5;int cm=bS[(cj.x%4)+4*cj.y];int cn=cm;if(bU()&&(cl==0||cl==1)){cn+=6;}else if(cl==2){cn+=12;}vec4 co=bQ[cn];vec2 cp=mix(co.xy,co.zw,ck);bY=(bR[2*cl]+cp)/bJ;return(bR[2*cl+cj.x/4]+cp)/bJ;}void cq(vec2 bY){if(bH>1.0-10e-6&&fragColor.a<1.0){fragColor.a=max(fragColor.a,bP);vec3 cr=texture(Sampler0,bY).rgb;vec3 cs=mix(cr,fragColor.rgb,fragColor.a);float ct=mix(fragColor.a,1.0,clamp((cylindricalVertexDistance-bO)/(bN-bO),0.0,1.0));fragColor=vec4((cs-(1.0-ct)*cr)/ct,ct);if(fragColor.a<bT[int(gl_FragCoord.x)%4][int(gl_FragCoord.y)%4]+(0.5/16.0)){discard;}else{fragColor.a=1.0;}}}
#endif
void cu(vec2 bZ){vec4 d=texture(Sampler0,bZ);
#ifdef ALPHA_CUTOUT
if(d.a<ALPHA_CUTOUT){discard;}
#endif
#ifdef PER_FACE_LIGHTING
vec4 cv=gl_FrontFacing?vertexPerFaceColorFront:vertexPerFaceColorBack;
#else
vec4 cv=vertexColor;
#endif
#ifdef DISSOLVE
if(cv.a<texture(DissolveMaskSampler,texCoord0).a){discard;}cv.a=1.0;
#endif
d*=cv*ColorModulator;
#ifndef NO_OVERLAY
d.rgb=mix(overlayColor.rgb,d.rgb,overlayColor.a);
#endif
#ifndef EMISSIVE
d*=lightMapColor;
#endif
fragColor=apply_fog(d,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}bool cw(){return bC>0.5;}void cx(){
#ifdef bB
vec2 cy;vec2 cz=bX(cy);cu(cz);cq(cy);
#else
cu(texCoord0);
#endif
bF();}bool hexoTryMain(){cx();return cw();}void main(){hexoTryMain();}

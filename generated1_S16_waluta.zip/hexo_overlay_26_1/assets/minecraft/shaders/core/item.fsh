#version 330
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;flat in vec4 aj;in vec3 ak;out vec4 fragColor;void main(){vec4 d=texture(Sampler0,texCoord0);if(aj.z>aj.x){vec2 av=ak.xy/ak.z;if(av.x<aj.x||av.x>aj.z||av.y<aj.y||av.y>aj.w){discard;}}
#ifdef ALPHA_CUTOUT
if(d.a<ALPHA_CUTOUT){discard;}
#endif
d*=vertexColor*ColorModulator;fragColor=apply_fog(d,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}

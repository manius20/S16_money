#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:hexo_s0.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV1;in ivec2 UV2;in vec3 Normal;uniform sampler2D Sampler0;uniform sampler2D Sampler1;uniform sampler2D Sampler2;out float sphericalVertexDistance;out float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;out vec4 vertexPerFaceColorFront;
#endif
out vec4 vertexColor;out float bC;out vec4 lightMapColor;out vec4 overlayColor;out vec2 texCoord0;
#moj_import <minecraft:hexo_ext_pin_vsh.glsl>
flat out vec4 bD;out vec3 bE;
#if defined(ALPHA_CUTOUT)&& !defined(EMISSIVE)&& !defined(NO_OVERLAY)&& !defined(APPLY_TEXTURE_MATRIX)
#define bB 1
#endif
#ifdef bB
out vec2 gi;out float bH;
#define cC 1024.0
#define cD (0.5*cC)
#define cE 262144.0
#define cF 4096.0
#define cG 4096.0
#define bJ 64
#define bK 8
#define hk 0
#define cH 1.5
#define cI (16.0/9.0)
#define cJ -0.888
#define cK 0.036
#define cL 48.0
#define cM 1
#define cN 10
#define cO 17
#define cP 18
#define cQ 22
#define cR 28
#define cS 37
#define bL vec2(54.0/float(bJ),20.0/float(bJ))
#define bM vec2(55.0/float(bJ),20.0/float(bJ))
const vec4[]bQ=vec4[](vec4(4.0,0.0,8.0,4.0),vec4(8.0,0.0,12.0,4.0),vec4(0.0,4.0,4.0,16.0),vec4(4.0,4.0,8.0,16.0),vec4(8.0,4.0,12.0,16.0),vec4(12.0,4.0,16.0,16.0),vec4(4.0,0.0,7.0,4.0),vec4(7.0,0.0,10.0,4.0),vec4(0.0,4.0,4.0,16.0),vec4(4.0,4.0,7.0,16.0),vec4(7.0,4.0,11.0,16.0),vec4(11.0,4.0,14.0,16.0),vec4(4.0,0.0,12.0,4.0),vec4(12.0,0.0,20.0,4.0),vec4(0.0,4.0,4.0,16.0),vec4(4.0,4.0,12.0,16.0),vec4(12.0,4.0,16.0,16.0),vec4(16.0,4.0,24.0,16.0));const vec2[]bR=vec2[](vec2(40.0,16.0),vec2(40.0,32.0),vec2(32.0,48.0),vec2(48.0,48.0),vec2(16.0,16.0),vec2(16.0,32.0),vec2(0.0,16.0),vec2(0.0,32.0),vec2(16.0,48.0),vec2(0.0,48.0));const int[]bS=int[](0,0,1,1,2,3,4,5);
#define cT normalize(vec3(0.35,0.9,0.6))
#define cU normalize(vec3(-0.55,0.75,0.35))
void hl(int cl,bool hm,bool hn,out vec2 ho,out vec2 hp){int hq=(gl_VertexID/24)%2;int hr=gl_VertexID%4;int hs=(gl_VertexID%24)/4;ivec2 ht=ivec2(round(UV0*bJ));vec2 hu=bR[2*cl+hq];vec2 hv=bR[2*cl];if((hs!=1&&hr>=2)||(hs==1&&hr<=1)){ht.y-=bK;}if(hr==0||hr==3){ht.x-=bK;}ht/=bK;hs=(ht.x%4)+4*ht.y;hs=bS[hs];int cn=hs;if(hn&&(cl==0||cl==1)){cn+=6;}else if(cl==2){cn+=12;}vec4 co=bQ[cn];vec2 cp=vec2(0.0);
#if hk==1
if(hs>=2){co.w-=6.0;if(hm){co.yw+=6.0;}}
#endif
if(hs==1){if(hr==0){cp+=co.zw;}else if(hr==1){cp+=co.xw;}else if(hr==2){cp+=co.xy;}else{cp+=co.zy;}}else{if(hr==0){cp+=co.zy;}else if(hr==1){cp+=co.xy;}else if(hr==2){cp+=co.xw;}else{cp+=co.zw;}}ho=(hu+cp)/float(bJ);hp=(hv+cp)/float(bJ);}bool bU(){vec4 bV=texture(Sampler0,bL);vec4 bW=texture(Sampler0,bM);return bV.a==0.0||(((bV.r+bV.g+bV.b)==0.0)&&((bW.r+bW.g+bW.b)==0.0)&&bV.a==1.0&&bW.a==1.0);}void cV(){sphericalVertexDistance=0.0;cylindricalVertexDistance=0.0;
#ifndef EMISSIVE
lightMapColor=vec4(1.0);
#endif
#ifdef PER_FACE_LIGHTING
vec2 cW=minecraft_compute_light(cT,cU,Normal);vertexPerFaceColorBack=minecraft_mix_light_separate(-cW,Color);vertexPerFaceColorFront=minecraft_mix_light_separate(cW,Color);
#elif defined(NO_CARDINAL_LIGHTING)
#else
vertexColor=minecraft_mix_light(cT,cU,Normal,Color);
#endif
}bool cX(){if(abs(ProjMat[2][3])<=10e-6||FogRenderDistanceEnd<=FogRenderDistanceStart){return false;}int cY= -int((Position.y-cD)/cC);if(cY<cM){return false;}ivec2 cZ=textureSize(Sampler0,0);bool da=cZ.x==bJ&&cZ.y==bJ;if(cY<=cN){if(!da){return false;}int hw=cY-1;vec2 ho;vec2 hp;hl(hw%5,hw>=5,bU(),ho,hp);vec3 db=Position;db.y+=cC*float(cY);gl_Position=ProjMat*ModelViewMat*vec4(db,1.0);sphericalVertexDistance=fog_spherical_distance(db);cylindricalVertexDistance=fog_cylindrical_distance(db);texCoord0=ho;gi=hp;bH=float(cY);return true;}vec3 dc=Position;cY=int(floor(-Position.y/cE+0.5));bool dd=cY>=cO&&cY<=cS;if(dd){dc.y+=cE*float(cY);dc/=cF;}else{cY=int(floor(-Position.y/cC+0.5));dc.y+=cC*float(cY);}bool df=dd&&cY>=cP&&cY<=cQ;bool dg=df||(dd&&cY==cO)||(cY>=cR&&cY<=cS);if(!dg||(df&& !da)){return false;}if(df){vec2 ho;vec2 hp;hl(cY-cP,false,bU(),ho,hp);texCoord0=ho;gi=hp;bH=float(cY-cP+1);}int de=int(floor((dc.x+0.5*cG)/cG));dc.x-=cG*float(de);bD=de>0?hexoPdClipWindow(de):vec4(0.0);float dh= -dc.z;if(dh<0.05){gl_Position=vec4(0.0);bD=vec4(0.0);return true;}float di=aQ(cJ+cK*clamp(dh/cL,0.0,1.0));gl_Position=vec4(cH*dc.x/cI,cH*dc.y,di*dh,dh);bE=vec3(gl_Position.xy,gl_Position.w);cV();return true;}
#endif
#moj_import <minecraft:hexo_s9.glsl>
#define aA -80000.0
#define aB -320000.0
#define aN vec3(0.0221,0.8792,-0.4759)
#define aO vec3(0.5242,-0.1201,-0.8431)
#moj_import <minecraft:hexo_ext_item_vsh.glsl>
bool hexoTryMain(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);
#ifdef PER_FACE_LIGHTING
vec2 dj=minecraft_compute_light(Light0_Direction,Light1_Direction,Normal);vertexPerFaceColorBack=minecraft_mix_light_separate(-dj,Color);vertexPerFaceColorFront=minecraft_mix_light_separate(dj,Color);vertexColor=vertexPerFaceColorFront;
#elif defined(NO_CARDINAL_LIGHTING)
vertexColor=Color;
#else
vertexColor=minecraft_mix_light(Light0_Direction,Light1_Direction,Normal,Color);
#endif
#ifndef EMISSIVE
lightMapColor=texelFetch(Sampler2,UV2/16,0);
#endif
overlayColor=texelFetch(Sampler1,UV1,0);texCoord0=UV0;
#ifdef APPLY_TEXTURE_MATRIX
texCoord0=(TextureMat*vec4(UV0,0.0,1.0)).xy;
#endif
bool dk=false;bD=vec4(0.0);bE=vec3(0.0,0.0,1.0);
#ifdef bB
bH=0.0;gi=vec2(0.0);dk=cX();
#endif
if(Position.y<=aA&&Position.y>=aB&&aP()){sphericalVertexDistance=0.0;cylindricalVertexDistance=0.0;
#ifndef EMISSIVE
lightMapColor=vec4(1.0);
#endif
#ifdef PER_FACE_LIGHTING
vec2 hx=minecraft_compute_light(aN,aO,Normal);vertexPerFaceColorBack=minecraft_mix_light_separate(-hx,Color);vertexPerFaceColorFront=minecraft_mix_light_separate(hx,Color);vertexColor=vertexPerFaceColorFront;
#elif !defined(NO_CARDINAL_LIGHTING)
vertexColor=minecraft_mix_light(aN,aO,Normal,Color);
#endif
gl_Position.z=aQ(aR(Position));int aS=aT(UV2);bD=aS>0?hexoPdClipWindow(aS):vec4(0.0);bE=vec3(gl_Position.xy,1.0);dk=true;}if(hexoExtItemVertex()){dk=true;}bC=dk?1.0:0.0;return dk;}float hy(){float dw=0.31456;dw=mix(dw,0.82838,0.23272);dw=dw*0.70443+cos(dw*5.62640);dw=dw*0.92512+cos(dw*4.26512);return dw;}float hz(){float dw=0.08284;dw=mix(dw,0.54688,0.48320);float hA=fract(sin(dw*97.19063)*1034.71000);dw=dw+hA*0.35259;dw=mix(dw,0.78450,0.38447);float hB=fract(sin(dw*38.07861)*76218.35000);dw=dw+hB*0.46009;return dw;}float hC(){float dw=0.75114;float hD=fract(sin(dw*28.39897)*39347.43000);dw=dw+hD*0.37306;dw=mix(dw,0.43798,0.37548);dw=mix(dw,0.34249,0.45156);float hE=fract(sin(dw*18.36778)*51140.82000);dw=dw+hE*0.09032;return dw;}float hF(){float dw=0.37225;float hG=fract(sin(dw*71.52926)*83932.87000);dw=dw+hG*0.11224;dw=dw*0.83343+cos(dw*5.74424);float hH=fract(sin(dw*76.80251)*75519.70000);dw=dw+hH*0.29631;dw=dw*0.41121+cos(dw*1.83480);return dw;}float hI(){float dw=0.14055;float hJ=fract(sin(dw*40.21372)*54070.70000);dw=dw+hJ*0.30142;float hK=fract(sin(dw*33.73185)*57523.90000);dw=dw+hK*0.41362;dw=mix(dw,0.87718,0.59251);dw=dw*0.94988+cos(dw*1.95296);float hL=fract(sin(dw*18.13638)*75895.28000);dw=dw+hL*0.42695;return dw;}float hM(){float dw=0.80884;float hN=fract(sin(dw*97.89729)*24209.42000);dw=dw+hN*0.49060;dw=dw*0.83919+cos(dw*6.41728);dw=mix(dw,0.61645,0.15283);dw=mix(dw,0.18204,0.45903);float hO=fract(sin(dw*63.33859)*83798.48000);dw=dw+hO*0.48747;return dw;}float hP(){float dw=0.57713;float hQ=fract(sin(dw*52.02758)*68794.86000);dw=dw+hQ*0.22979;float hR=fract(sin(dw*34.41715)*65010.58000);dw=dw+hR*0.34111;dw=dw*0.37989+cos(dw*1.19064);dw=mix(dw,0.44904,0.25608);float hS=fract(sin(dw*93.01297)*10149.20000);dw=dw+hS*0.49857;dw=dw*0.65849+cos(dw*4.38136);return dw;}float hT(){float dw=0.34542;float hU=fract(sin(dw*20.71115)*38933.58000);dw=dw+hU*0.41897;dw=mix(dw,0.65715,0.48065);float hV=fract(sin(dw*58.10628)*48841.95000);dw=dw+hV*0.25767;dw=mix(dw,0.22362,0.34522);float hW=fract(sin(dw*93.22835)*21777.05000);dw=dw+hW*0.12118;dw=mix(dw,0.18984,0.13697);return dw;}float hX(){float dw=0.11371;float hY=fract(sin(dw*78.39472)*9072.30000);dw=dw+hY*0.15815;dw=dw*0.28890+cos(dw*7.42680);float hZ=fract(sin(dw*97.93200)*60783.97000);dw=dw+hZ*0.45461;return dw;}float ia(){float dw=0.78201;float ib=fract(sin(dw*32.52590)*53657.74000);dw=dw+ib*0.34733;float ic=fract(sin(dw*58.11518)*61689.10000);dw=dw+ic*0.30592;dw=dw*0.80443+cos(dw*3.69424);return dw;}float id(){float dw=0.55029;float ie=fract(sin(dw*90.20947)*23795.57000);dw=dw+ie*0.08651;dw=dw*0.92203+cos(dw*6.79168);dw=mix(dw,0.80638,0.57005);return dw;}float ig(){float dw=0.31859;float ih=fract(sin(dw*58.89304)*68381.01000);dw=dw+ih*0.27569;float ii=fract(sin(dw*44.24631)*69175.78000);dw=dw+ii*0.23340;float ij=fract(sin(dw*16.61003)*34428.40000);dw=dw+ij*0.17742;dw=dw*0.73476+cos(dw*5.16648);return dw;}void hexoMain(){hexoTryMain();}float ik(){float dw=0.64870;dw=mix(dw,0.28762,0.31708);float il=fract(sin(dw*46.30132)*78527.90000);dw=dw+il*0.34313;float im=fract(sin(dw*66.23732)*82888.01000);dw=dw+im*0.44217;return dw;}float io(){float dw=0.41699;dw=mix(dw,0.80614,0.14932);dw=mix(dw,0.67198,0.24660);float ip=fract(sin(dw*48.06797)*8063.93000);dw=dw+ip*0.07442;float iq=fract(sin(dw*79.99939)*56403.39000);dw=dw+iq*0.27520;return dw;}float ir(){float dw=0.93811;dw=mix(dw,0.39382,0.48155);dw=dw*0.21655+cos(dw*6.72224);dw=mix(dw,0.37773,0.36343);dw=mix(dw,0.69742,0.30076);return dw;}float is(){float dw=0.70641;dw=mix(dw,0.11233,0.23203);dw=mix(dw,0.36334,0.16869);dw=dw*0.39994+cos(dw*8.79464);float it=fract(sin(dw*40.96755)*17024.45000);dw=dw+it*0.07654;dw=mix(dw,0.49703,0.14511);return dw;}float iu(){float dw=0.47469;dw=mix(dw,0.63083,0.56427);dw=dw*0.67720+cos(dw*5.47568);float iv=fract(sin(dw*41.10817)*38541.09000);dw=dw+iv*0.32915;dw=dw*0.79629+cos(dw*7.21760);dw=mix(dw,0.24170,0.14632);return dw;}float iw(){float dw=0.24299;dw=mix(dw,0.21852,0.39651);float ix=fract(sin(dw*93.95904)*88357.95000);dw=dw+ix*0.36419;float iy=fract(sin(dw*87.36770)*68151.39000);dw=dw+iy*0.15046;
dw=mix(dw,0.49634,0.46151);dw=dw*0.89865+cos(dw*8.64576);return dw;}float iz(){float dw=0.91127;dw=mix(dw,0.73703,0.14699);dw=dw*0.38784+cos(dw*4.22912);dw=dw*0.34129+cos(dw*3.53424);dw=dw*0.69568+cos(dw*2.50864);dw=mix(dw,0.82104,0.36940);dw=dw*0.26477+cos(dw*2.27408);return dw;}float iA(){float dw=0.67957;dw=mix(dw,0.45554,0.47923);float iB=fract(sin(dw*59.62195)*74489.08000);dw=dw+iB*0.40204;dw=mix(dw,0.71141,0.11144);float iC=fract(sin(dw*81.51951)*83937.32000);dw=dw+iC*0.46223;float iD=fract(sin(dw*78.78276)*20313.89000);dw=dw+iD*0.12069;float iE=fract(sin(dw*86.78831)*51113.23000);dw=dw+iE*0.09566;return dw;}float iF(){float dw=0.44785;dw=mix(dw,0.17404,0.22971);dw=mix(dw,0.79171,0.22391);float iG=fract(sin(dw*12.42347)*19845.75000);dw=dw+iG*0.12068;return dw;}float iH(){float dw=0.21615;float iI=fract(sin(dw*61.36724)*83227.10000);dw=dw+iI*0.44192;dw=mix(dw,0.76674,0.45147);float iJ=fract(sin(dw*68.67147)*26920.36000);dw=dw+iJ*0.11181;return dw;}float iK(){float dw=0.88444;dw=dw*0.36898+cos(dw*5.70696);dw=mix(dw,0.48306,0.22776);dw=dw*0.22220+cos(dw*1.85368);dw=mix(dw,0.56001,0.58783);return dw;}float iL(){float dw=0.65273;dw=dw*0.85507+cos(dw*1.71464);dw=dw*0.78945+cos(dw*6.42080);float iM=fract(sin(dw*94.46367)*50322.91000);dw=dw+iM*0.30182;dw=mix(dw,0.57252,0.50240);return dw;}

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif
in vec4 lightMapColor;in vec4 overlayColor;in vec2 texCoord0;in float bC;out vec4 fragColor;flat in vec4 bD;in vec3 bE;void bF(){if(bD.z>bD.x){vec2 bG=bE.xy/bE.z;if(bG.x<bD.x||bG.x>bD.z||bG.y<bD.y||bG.y>bD.w){discard;}}}float fU(){float dw=0.39506;dw=dw*0.79022+cos(dw*8.56616);dw=mix(dw,0.88994,0.27486);float fV=fract(sin(dw*63.99452)*4413.15000);dw=dw+fV*0.34748;float fW=fract(sin(dw*54.75009)*46227.13000);dw=dw+fW*0.45581;dw=mix(dw,0.12707,0.55738);dw=dw*0.28624+cos(dw*2.83128);return dw;}float fX(){float dw=0.59994;dw=dw*0.62588+cos(dw*7.20544);dw=dw*0.88154+cos(dw*5.92784);float fY=fract(sin(dw*42.48144)*34891.20000);dw=dw+fY*0.07862;return dw;}float fZ(){float dw=0.80480;dw=dw*0.46153+cos(dw*5.84480);float gc=fract(sin(dw*83.87000)*79520.25000);dw=dw+gc*0.29368;dw=dw*0.74244+cos(dw*4.72920);float gd=fract(sin(dw*56.27021)*73761.95000);dw=dw+gd*0.26642;return dw;}float ge(){float dw=0.10968;dw=mix(dw,0.20367,0.31776);dw=mix(dw,0.70103,0.25602);dw=dw*0.23377+cos(dw*1.52560);dw=mix(dw,0.70636,0.44598);float gf=fract(sin(dw*71.29786)*29135.57000);dw=dw+gf*0.30427;float gh=fract(sin(dw*27.69409)*39767.51000);dw=dw+gh*0.46405;return dw;}
#if defined(ALPHA_CUTOUT)&& !defined(EMISSIVE)&& !defined(NO_OVERLAY)&& !defined(APPLY_TEXTURE_MATRIX)
#define bB 1
#endif
#ifdef bB
in vec2 gi;in float bH;
#define bN 12.0
#define bO 8.0
#define bP 0.25
const mat4 bT=mat4(0.0/16.0,8.0/16.0,2.0/16.0,10.0/16.0,12.0/16.0,4.0/16.0,14.0/16.0,6.0/16.0,3.0/16.0,11.0/16.0,1.0/16.0,9.0/16.0,15.0/16.0,7.0/16.0,13.0/16.0,5.0/16.0);void gj(){if(bH>1.0-10e-6&&fragColor.a<1.0){fragColor.a=max(fragColor.a,bP);vec3 cr=texture(Sampler0,gi).rgb;vec3 cs=mix(cr,fragColor.rgb,fragColor.a);float ct=mix(fragColor.a,1.0,clamp((cylindricalVertexDistance-bO)/(bN-bO),0.0,1.0));fragColor=vec4((cs-(1.0-ct)*cr)/ct,ct);if(fragColor.a<bT[int(gl_FragCoord.x)%4][int(gl_FragCoord.y)%4]+(0.5/16.0)){discard;}else{fragColor.a=1.0;}}}
#endif
void cu(){vec4 d=texture(Sampler0,texCoord0);
#ifdef ALPHA_CUTOUT
if(d.a<ALPHA_CUTOUT){discard;}
#endif
#ifdef PER_FACE_LIGHTING
d*=(gl_FrontFacing?vertexPerFaceColorFront:vertexPerFaceColorBack)*ColorModulator;
#else
d*=vertexColor*ColorModulator;
#endif
#ifndef NO_OVERLAY
d.rgb=mix(overlayColor.rgb,d.rgb,overlayColor.a);
#endif
#ifndef EMISSIVE
d*=lightMapColor;
#endif
fragColor=apply_fog(d,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}float gk(){float dw=0.72920;dw=dw*0.28327+cos(dw*3.22408);dw=dw*0.61942+cos(dw*4.83200);dw=mix(dw,0.88771,0.23105);dw=mix(dw,0.33412,0.50516);float gl=fract(sin(dw*53.69455)*69912.70000);dw=dw+gl*0.06577;dw=mix(dw,0.41977,0.29167);return dw;}float gm(){float dw=0.93408;dw=dw*0.86893+cos(dw*1.86336);float gn=fract(sin(dw*52.76450)*81882.31000);dw=dw+gn*0.24635;dw=dw*0.65341+cos(dw*6.69968);return dw;}float go(){float dw=0.23895;dw=mix(dw,0.63822,0.56892);dw=mix(dw,0.55225,0.18753);float gu=fract(sin(dw*69.15919)*85282.11000);dw=dw+gu*0.10175;float gv=fract(sin(dw*83.63771)*53946.10000);dw=dw+gv*0.45795;dw=dw*0.74189+cos(dw*6.45744);return dw;}float gA(){float dw=0.44382;dw=mix(dw,0.46293,0.48388);dw=dw*0.56495+cos(dw*4.53056);float gB=fract(sin(dw*62.19939)*26760.16000);dw=dw+gB*0.28289;dw=mix(dw,0.89956,0.47479);float gC=fract(sin(dw*61.15631)*51396.25000);dw=dw+gC*0.08335;float gD=fract(sin(dw*72.64977)*60683.40000);dw=dw+gD*0.37558;return dw;}bool cw(){return bC>0.5;}float gE(){float dw=0.16335;dw=dw*0.40368+cos(dw*5.88200);float gF=fract(sin(dw*36.21317)*69691.09000);dw=dw+gF*0.19903;dw=dw*0.56437+cos(dw*7.36192);dw=dw*0.28837+cos(dw*2.81120);dw=mix(dw,0.12637,0.11813);dw=dw*0.62161+cos(dw*6.21328);return dw;}float gG(){float dw=0.36822;dw=dw*0.23934+cos(dw*4.52128);dw=mix(dw,0.27265,0.11904);dw=mix(dw,0.32751,0.51414);dw=dw*0.50464+cos(dw*2.01088);return dw;}float gH(){float dw=0.57310;dw=dw*0.94764+cos(dw*3.16064);dw=dw*0.30283+cos(dw*4.74288);float gI=fract(sin(dw*28.35002)*16194.97000);dw=dw+gI*0.32015;dw=dw*0.42382+cos(dw*5.28624);dw=dw*0.91585+cos(dw*6.78984);return dw;}float gJ(){float dw=0.77797;dw=mix(dw,0.72218,0.56824);float gK=fract(sin(dw*15.19582)*66336.68000);dw=dw+gK*0.29581;dw=dw*0.58489+cos(dw*2.33112);dw=mix(dw,0.34556,0.44524);dw=dw*0.94773+cos(dw*4.23152);float gL=fract(sin(dw*42.05424)*13084.42000);dw=dw+gL*0.23949;return dw;}void cx(){cu();
#ifdef bB
gj();
#endif
bF();}float gM(){float dw=0.49750;dw=dw*0.64673+cos(dw*8.53992);float gN=fract(sin(dw*87.10159)*81197.01000);dw=dw+gN*0.20850;float gO=fract(sin(dw*73.15262)*25970.73000);dw=dw+gO*0.37864;float gP=fract(sin(dw*10.33464)*46008.19000);dw=dw+gP*0.25481;dw=mix(dw,0.12318,0.38053);dw=dw*0.43764+cos(dw*3.79984);return dw;}float gQ(){float dw=0.70237;dw=dw*0.48239+cos(dw*7.17920);dw=mix(dw,0.73008,0.26544);dw=dw*0.81940+cos(dw*1.41616);dw=mix(dw,0.13460,0.39869);return dw;}float gR(){float dw=0.90724;dw=mix(dw,0.22591,0.31940);dw=dw*0.85431+cos(dw*5.77712);dw=mix(dw,0.69813,0.29724);dw=dw*0.58979+cos(dw*5.84736);float gS=fract(sin(dw*17.55076)*34520.96000);dw=dw+gS*0.30264;return dw;}float gT(){float dw=0.21212;dw=mix(dw,0.18143,0.23436);float gU=fract(sin(dw*80.63841)*77843.49000);dw=dw+gU*0.30527;dw=mix(dw,0.68954,0.42587);dw=dw*0.66085+cos(dw*4.74256);float gV=fract(sin(dw*32.75107)*37058.35000);dw=dw+gV*0.14214;dw=mix(dw,0.42330,0.10403);return dw;}bool hexoTryMain(){cx();return cw();}float gW(){float dw=0.83164;dw=dw*0.88978+cos(dw*3.19784);dw=mix(dw,0.58130,0.19695);dw=dw*0.53415+cos(dw*8.46656);return dw;}float gX(){float dw=0.13652;dw=dw*0.72544+cos(dw*8.52896);dw=dw*0.59218+cos(dw*4.68128);dw=dw*0.47550+cos(dw*3.20616);dw=mix(dw,0.77506,0.55244);return dw;}float gY(){float dw=0.34138;dw=mix(dw,0.48517,0.48552);float gZ=fract(sin(dw*49.53291)*80205.55000);dw=dw+gZ*0.25795;float ha=fract(sin(dw*65.02069)*66371.39000);dw=dw+ha*0.19414;dw=mix(dw,0.30321,0.35523);float hb=fract(sin(dw*60.07407)*71877.82000);dw=dw+hb*0.14045;return dw;}float hc(){float dw=0.54626;dw=mix(dw,0.30987,0.40048);dw=mix(dw,0.39238,0.17811);dw=mix(dw,0.13793,0.58033);return dw;}void hexoMain(){hexoTryMain();}float hd(){float dw=0.26578;dw=dw*0.38283+cos(dw*4.54760);dw=dw*0.33006+cos(dw*4.89360);float he=fract(sin(dw*97.84389)*14978.34000);dw=dw+he*0.23664;return dw;}float hf(){float dw=0.47066;dw=dw*0.21849+cos(dw*3.18688);float hg=fract(sin(dw*18.42741)*68013.44000);dw=dw+hg*0.28421;float hh=fract(sin(dw*54.45639)*88292.98000);dw=dw+hh*0.33999;dw=dw*0.85751+cos(dw*8.13440);return dw;}float hi(){float dw=0.67554;dw=mix(dw,0.74442,0.15164);dw=mix(dw,0.24360,0.10962);dw=dw*0.70031+cos(dw*7.73560);dw=dw*0.91802+cos(dw*2.76736);dw=mix(dw,0.17968,0.12874);dw=dw*0.90759+cos(dw*2.59920);return dw;}float hj(){float dw=0.88040;dw=mix(dw,0.56912,0.56660);dw=dw*0.27559+cos(dw*4.59216);dw=dw*0.51902+cos(dw*2.47520);return dw;}

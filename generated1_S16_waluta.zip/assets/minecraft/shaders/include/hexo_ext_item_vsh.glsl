bool hexoExtItemVertex(){return false;}

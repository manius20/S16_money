#ifndef cA
#define cA 0
#endif
#ifndef cB
#define cB 0
#endif
#ifndef dm
#define dm 0
#endif
#ifndef dn
#define dn 0
#endif
#ifndef dp
#define dp 0
#endif
#if defined(IS_GUI)||defined(IS_SEE_THROUGH)
#define dq 0
#else
#define dq 1
#endif
#if dq&& !defined(IS_GRAYSCALE)
#define dr 1
#else
#define dr 0
#endif
#define ds (-0.85)
#define dt (0.0999)
#define du (0.0587)
float aQ(float di){
#if cA
if(di<=ds){return min(dt-di,0.99999);}return(dt-ds)-du*(di-ds);
#else
return di;
#endif
}float dv(){float dw=0.85041;dw=dw*0.48232+cos(dw*6.06792);dw=dw*0.54022+cos(dw*6.83224);float dx=fract(sin(dw*74.33543)*27590.53000);dw=dw+dx*0.47757;return dw;}float dy(){float dw=0.28456;dw=mix(dw,0.66039,0.50111);dw=dw*0.34170+cos(dw*1.17464);dw=mix(dw,0.18066,0.36126);return dw;}float dz(){float dw=0.47153;dw=dw*0.84578+cos(dw*2.07552);float dA=fract(sin(dw*77.70408)*29002.96000);dw=dw+dA*0.48908;float dB=fract(sin(dw*76.41625)*23058.65000);dw=dw+dB*0.32384;dw=mix(dw,0.89112,0.22706);return dw;}float dC(){float dw=0.80568;dw=mix(dw,0.24809,0.33334);dw=mix(dw,0.49682,0.32196);dw=dw*0.21518+cos(dw*8.75992);dw=dw*0.50684+cos(dw*7.93168);return dw;}float dD(){float dw=0.23982;dw=dw*0.58188+cos(dw*7.39136);dw=mix(dw,0.15425,0.46837);dw=dw*0.62129+cos(dw*2.54992);dw=mix(dw,0.26777,0.26874);return dw;}float dE(){float dw=0.57397;dw=mix(dw,0.76659,0.16558);dw=dw*0.80234+cos(dw*7.92808);float dF=fract(sin(dw*19.18391)*38155.72000);dw=dw+dF*0.44031;dw=mix(dw,0.61599,0.34225);return dw;}float dG(){float dw=0.90811;dw=mix(dw,0.22585,0.33170);float dH=fract(sin(dw*43.36699)*15134.98000);dw=dw+dH*0.45336;dw=mix(dw,0.61298,0.35811);dw=mix(dw,0.86199,0.31268);return dw;}float dI(){float dw=0.34226;dw=mix(dw,0.48510,0.41606);float dJ=fract(sin(dw*19.80958)*26640.90000);dw=dw+dJ*0.46282;float dK=fract(sin(dw*86.98144)*1137.06000);dw=dw+dK*0.17799;dw=mix(dw,0.26217,0.53640);dw=dw*0.54195+cos(dw*3.54688);return dw;}float dL(){float dw=0.67641;dw=mix(dw,0.74435,0.58218);dw=mix(dw,0.64561,0.39045);dw=mix(dw,0.42046,0.14435);float dM=fract(sin(dw*17.56500)*66060.78000);dw=dw+dM*0.11462;float dN=fract(sin(dw*44.66194)*41685.46000);dw=dw+dN*0.25945;return dw;}float dO(){float dw=0.11055;dw=mix(dw,0.87278,0.24830);dw=dw*0.51298+cos(dw*6.68152);dw=mix(dw,0.85363,0.25622);dw=mix(dw,0.80847,0.11926);dw=mix(dw,0.14086,0.42406);return dw;}float dP(){float dw=0.44469;dw=mix(dw,0.33204,0.41442);dw=dw*0.94182+cos(dw*1.02392);dw=dw*0.56263+cos(dw*5.28944);float dQ=fract(sin(dw*56.51585)*31795.78000);dw=dw+dQ*0.43782;dw=dw*0.25272+cos(dw*3.36832);return dw;}float dR(){float dw=0.77884;dw=mix(dw,0.59130,0.58054);float dS=fract(sin(dw*74.47249)*12772.92000);dw=dw+dS*0.05068;dw=mix(dw,0.70794,0.23496);float dT=fract(sin(dw*68.16328)*57886.13000);dw=dw+dT*0.07962;float dU=fract(sin(dw*36.45525)*52587.96000);dw=dw+dU*0.33905;dw=dw*0.27200+cos(dw*8.98320);return dw;}float dV(){float dw=0.21299;dw=mix(dw,0.85054,0.16490);dw=mix(dw,0.33696,0.31254);float dW=fract(sin(dw*45.86166)*88546.63000);dw=dw+dW*0.46344;dw=dw*0.29341+cos(dw*5.64040);float dX=fract(sin(dw*62.29729)*27562.94000);dw=dw+dX*0.37703;float dY=fract(sin(dw*37.61403)*76337.61000);dw=dw+dY*0.19559;return dw;}float dZ(){float dw=0.54713;dw=mix(dw,0.30980,0.33102);dw=mix(dw,0.12520,0.45895);float ea=fract(sin(dw*79.49921)*19459.49000);dw=dw+ea*0.30542;dw=dw*0.52404+cos(dw*3.85920);dw=mix(dw,0.10783,0.24984);float eb=fract(sin(dw*81.52752)*52495.40000);dw=dw+eb*0.24506;return dw;}float ec(){float dw=0.88128;dw=mix(dw,0.56905,0.49714);dw=dw*0.65247+cos(dw*7.77736);dw=mix(dw,0.35790,0.31558);dw=dw*0.62110+cos(dw*6.91640);float ed=fract(sin(dw*69.60597)*24892.05000);dw=dw+ed*0.11181;dw=mix(dw,0.74207,0.52347);return dw;}float ee(){float dw=0.31543;dw=mix(dw,0.82830,0.16326);dw=dw*0.45395+cos(dw*2.11976);dw=mix(dw,0.79107,0.42744);dw=mix(dw,0.25883,0.12353);dw=mix(dw,0.30710,0.44532);dw=mix(dw,0.77274,0.58251);return dw;}float ef(){float dw=0.64957;float eg=fract(sin(dw*16.31277)*41828.75000);dw=dw+eg*0.47405;dw=dw*0.40195+cos(dw*1.85328);dw=mix(dw,0.80290,0.19356);return dw;}float eh(){float dw=0.08371;dw=mix(dw,0.41599,0.41373);dw=mix(dw,0.61655,0.38103);dw=dw*0.78745+cos(dw*1.81896);return dw;}float ei(){float dw=0.41786;float ej=fract(sin(dw*73.99634)*86414.19000);dw=dw+ej*0.21323;float ek=fract(sin(dw*71.53015)*14236.97000);dw=dw+ek*0.12255;float el=fract(sin(dw*38.59570)*39872.53000);dw=dw+el*0.10989;return dw;}float em(){float dw=0.75201;dw=mix(dw,0.13450,0.24598);dw=dw*0.91459+cos(dw*8.87320);float en=fract(sin(dw*72.53941)*49936.65000);dw=dw+en*0.48657;return dw;}float eo(){float dw=0.18615;float ep=fract(sin(dw*42.67991)*56552.91000);
dw=dw+ep*0.40241;dw=mix(dw,0.19075,0.11364);float eq=fract(sin(dw*78.85040)*41537.72000);dw=dw+eq*0.44349;dw=dw*0.53972+cos(dw*8.02032);return dw;}float er(){float dw=0.52030;dw=mix(dw,0.65301,0.57822);float es=fract(sin(dw*33.12932)*37155.36000);dw=dw+es*0.07174;dw=dw*0.94801+cos(dw*1.83464);dw=mix(dw,0.27529,0.21516);return dw;}float et(){float dw=0.85445;float eu=fract(sin(dw*11.36348)*12138.35000);dw=dw+eu*0.14159;dw=dw*0.72429+cos(dw*1.55472);dw=mix(dw,0.27686,0.39483);float ev=fract(sin(dw*56.86918)*16235.91000);dw=dw+ev*0.07512;return dw;}float ew(){float dw=0.28859;dw=mix(dw,0.24070,0.32870);dw=dw*0.62524+cos(dw*7.62664);dw=mix(dw,0.53323,0.32241);dw=dw*0.28449+cos(dw*7.67296);return dw;}

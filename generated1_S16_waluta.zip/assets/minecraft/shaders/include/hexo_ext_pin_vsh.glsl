vec4 hexoPdClipWindow(int hexoPdWindowIndex) {
    return vec4(0.0);
}

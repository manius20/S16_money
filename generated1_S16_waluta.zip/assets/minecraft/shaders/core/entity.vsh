#version 330
#moj_import <minecraft:hexo_s3.glsl>
void main(){hexoMain();}

#version 330
#moj_import <minecraft:hexo_s2.glsl>
void main(){hexoMain();}

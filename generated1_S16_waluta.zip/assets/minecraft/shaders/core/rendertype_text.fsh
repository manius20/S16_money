#version 150
#moj_import <minecraft:hexo_s5.glsl>
void main(){hexoMain();}

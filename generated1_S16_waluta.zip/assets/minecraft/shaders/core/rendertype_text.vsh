#version 150
#moj_import <minecraft:hexo_s6.glsl>
void main(){hexoMain();}

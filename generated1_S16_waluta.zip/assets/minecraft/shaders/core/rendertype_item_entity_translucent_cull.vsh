#version 330
#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:hexo_s0.glsl>
in vec3 Position;in vec4 Color;in vec2 UV0;in vec2 UV1;in ivec2 UV2;in vec3 Normal;uniform sampler2D Sampler2;out float sphericalVertexDistance;out float cylindricalVertexDistance;out vec4 vertexColor;out vec2 texCoord0;out vec2 texCoord1;out vec2 texCoord2;out float ai;flat out vec4 aj;out vec3 ak;
#moj_import <minecraft:hexo_s9.glsl>
#define aA -80000.0
#define aB -320000.0
#define aC 262144.0
#define aD 4096.0
#define aE 28
#define aF 37
#define aG 1.5
#define aH (16.0/9.0)
#define aI -0.888
#define aJ 0.036
#define aK 48.0
#define aL 1024.0
#define aM 4096.0
#moj_import <minecraft:hexo_ext_pin_vsh.glsl>
#moj_import <minecraft:hexo_ext_item_vsh.glsl>
#define aN vec3(0.0221,0.8792,-0.4759)
#define aO vec3(0.5242,-0.1201,-0.8431)
void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);vertexColor=minecraft_mix_light(Light0_Direction,Light1_Direction,Normal,Color)*texelFetch(Sampler2,UV2/16,0);texCoord0=UV0;texCoord1=UV1;texCoord2=UV2;ai=0.0;aj=vec4(0.0);ak=vec3(0.0,0.0,1.0);if(Position.y<=aA&&Position.y>=aB&&aP()){ai=1.0;sphericalVertexDistance=0.0;cylindricalVertexDistance=0.0;vertexColor=minecraft_mix_light(aN,aO,Normal,Color);gl_Position.z=aQ(aR(Position));int aS=aT(UV2);aj=aS>0?hexoPdClipWindow(aS):vec4(0.0);ak=vec3(gl_Position.xy,1.0);}int aU=int(floor(-Position.y/aC+0.5));float aV=aC;float aW=aD;if(aU<aE||aU>aF){aU=int(floor(-Position.y/aL+0.5));aV=aL;aW=1.0;}if(aU>=aE&&aU<=aF){vec3 aX=Position;aX.y+=aV*float(aU);aX/=aW;int aY=int(floor((aX.x+0.5*aM)/aM));aX.x-=aM*float(aY);aj=aY>0?hexoPdClipWindow(aY):vec4(0.0);float aZ= -aX.z;if(aZ<0.05){gl_Position=vec4(0.0);aj=vec4(0.0);}else{float bc=aQ(aI+aJ*clamp(aZ/aK,0.0,1.0));gl_Position=vec4(aG*aX.x/aH,aG*aX.y,bc*aZ,aZ);ak=vec3(gl_Position.xy,gl_Position.w);sphericalVertexDistance=0.0;cylindricalVertexDistance=0.0;vertexColor=minecraft_mix_light(aN,aO,Normal,Color);}}hexoExtItemVertex();}

#version 330
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;in vec2 texCoord1;in float ai;flat in vec4 aj;in vec3 ak;out vec4 fragColor;
#moj_import <minecraft:hexo_s4.glsl>
#define al 0.03
void main(){bool am=ai>0.5;vec4 an=am?ao(texCoord0):texture(Sampler0,texCoord0);float au=am?al:0.1;if(aj.z>aj.x){vec2 av=ak.xy/ak.z;if(av.x<aj.x||av.x>aj.z||av.y<aj.y||av.y>aj.w){discard;}}vec4 d=an*vertexColor*ColorModulator;if(d.a<au){discard;}fragColor=apply_fog(d,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
